import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';


@Component({
  selector: 'app-varification-user',
  templateUrl: './varification-user.component.html',
  styleUrls: ['./varification-user.component.css']
})
export class VarificationUserComponent {
  verificationForm!: FormGroup;
  wsUri = 'wss://socketsbay.com/wss/v2/1/demo/';
  websocket: WebSocket | undefined;
  
  constructor(
    private formBuilder: FormBuilder, private router: Router,
    ) {}

ngOnInit() {
  this.verificationForm = this.formBuilder.group({    
      password: ['', Validators.required],
      tatcode: ['', Validators.required]
  });  
  this.connectWebSocket();
}


private connectWebSocket() {
  this.websocket = new WebSocket(this.wsUri);

  this.websocket.addEventListener('open', (event) => {
    console.log('WebSocket connection opened: verified', event);
  });

  this.websocket.addEventListener('message', (event) => {
    const message = event.data;      
    console.log('Received message verified:', message);
    const jsonData = JSON.parse(message) ? JSON.parse(message) : '';
      if(jsonData.status == '0')
      {
        console.log("Tatcode susscess");
        this.router.navigate(['/dashboard'])

      }
      if(jsonData.status == '1')
      {
        console.log("Tatcode LOGIN FAIL ");
        this.router.navigate(['/login'])
        
      }
  });

  this.websocket.addEventListener('close', (event) => {
    console.log('WebSocket connection closed verified:', event);
  });

  this.websocket.addEventListener('error', (event) => {
    console.error('WebSocket error verified:', event);
  });
}

onSubmit() {      
  const messageToSend = {
    userid: "test",
    username: this.verificationForm.get('password')?.value,
    password: this.verificationForm.get('tatcode')?.value,
  };
  if (this.websocket && this.websocket.readyState === WebSocket.OPEN) {
    this.websocket.send(JSON.stringify(messageToSend));
  }
  //console.log("messageToSend=>>",messageToSend);
 // this.router.navigate(['/dashboard']);
}
}
