import { Component, OnInit } from '@angular/core';
import { Router, Route } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  templateUrl: 'login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent implements OnInit {
  loginForm!: FormGroup;
  wsUri = 'wss://socketsbay.com/wss/v2/1/demo/'; // Updated WebSocket URI
  public websocket: WebSocket | undefined;
  log: any;
  NONMFA = false;

  constructor(private formBuilder: FormBuilder, private router: Router) {}

  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      username: ['', Validators.required],
      //password: ['', Validators.required],
    });

    // Connect to WebSocket when the component is initialized
    this.connectWebSocket();
  }

  private connectWebSocket() {
    this.websocket = new WebSocket(this.wsUri);

    this.websocket.addEventListener('open', (event) => {
      console.log('WebSocket connection opened:', event);
    });

    this.websocket.addEventListener('message', (event) => {
      const message = event.data;      
      console.log('Received message:', message);

      const jsonData = JSON.parse(message) ? JSON.parse(message) : '';

      if(jsonData.status == '0' && this.NONMFA)
      {
        console.log("verification success");
        this.router.navigate(['/dashboard'])
      }
      if(jsonData.status == '1')
      {
        console.log("Tatcode LOGIN FAIL ");
        this.router.navigate(['/login'])
        
      }


      if(jsonData.authtype == 'MFA')
      {
        console.log("MFA call");
        this.router.navigate(['/user-verify'])

      }
      if(jsonData.authtype == 'NONMFA' && jsonData.status == '0')
      {
        console.log("NONMFA call");
        this.NONMFA = true;
        this.router.navigate(['/waiting-time'])

      }
      
      // if(jsonData.status == '1')
      // {
      //   console.log("LOGIN FAIL ");
      //   this.router.navigate(['/login'])
        
      // }
      

    });

    this.websocket.addEventListener('close', (event) => {
      console.log('WebSocket connection closed:', event);
    });

    this.websocket.addEventListener('error', (event) => {
      console.error('WebSocket error:', event);
    });
  }

  get f() {
    return this.loginForm.controls;
  }

  onSubmit() {
    // Example: Send a message when the form is submitted
    const messageToSend = {
      username: this.loginForm.get('username')?.value,
      //password: this.loginForm.get('password')?.value,
    };

    if (this.websocket && this.websocket.readyState === WebSocket.OPEN) {
      this.websocket.send(JSON.stringify(messageToSend));
    }
  }
}
