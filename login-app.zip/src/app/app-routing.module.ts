import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {LoginComponent} from './login/login.component'
import { DashboardComponent } from './dashboard/dashboard.component';
import { VarificationUserComponent } from './varification-user/varification-user.component';
import { WaitingTimeComponent } from './waiting-time/waiting-time.component';

const routes: Routes = [  
  { path: 'login', component: LoginComponent },
  {path:'dashboard',component : DashboardComponent},
  {path:'user-verify',component:VarificationUserComponent},
  {path:'waiting-time',component:WaitingTimeComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
