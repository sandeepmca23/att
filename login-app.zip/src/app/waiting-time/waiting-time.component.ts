import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-waiting-time',
  templateUrl: './waiting-time.component.html',
  styleUrls: ['./waiting-time.component.css']
})
export class WaitingTimeComponent implements OnInit {
  showLoader: boolean = true;
  remainingMinutes: number = 10;
  remainingSeconds: number = 0;

  ngOnInit() {
    let totalTimeInSeconds = this.remainingMinutes * 60 + this.remainingSeconds;

    const countdownInterval = setInterval(() => {
      totalTimeInSeconds--;

      this.remainingMinutes = Math.floor(totalTimeInSeconds / 60);
      this.remainingSeconds = totalTimeInSeconds % 60;

      if (totalTimeInSeconds <= 0) {
        clearInterval(countdownInterval);
        this.showLoader = false;
      }
    }, 1000); // Update every second
  }
}
