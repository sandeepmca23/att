package com.itexcellence.core.exception;

public class CertainException {

}
