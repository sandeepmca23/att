package com.itexcellence.core.model;

import java.util.ArrayList;
import java.util.List;

import lombok.Data;

@Data
public class DepartmentVO2 extends DepartmentVO{
	@SuppressWarnings("unused")
	private List<EmployeeVO> employeeVOList = new ArrayList<>();
}
