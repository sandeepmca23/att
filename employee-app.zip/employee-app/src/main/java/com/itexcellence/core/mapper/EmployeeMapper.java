package com.itexcellence.core.mapper;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.itexcellence.core.entity.Employee;
import com.itexcellence.core.model.EmployeeVO;

@Mapper
public interface EmployeeMapper {

    EmployeeMapper INSTANCE = Mappers.getMapper(EmployeeMapper.class);

    Employee toEntity(EmployeeVO vo);

    EmployeeVO toVO(Employee entity);
}
