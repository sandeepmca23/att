package com.itexcellence.core.controller.exception.handler;

import java.time.LocalDateTime;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;

import com.itexcellence.core.constants.MessageConstants;
import com.itexcellence.core.exception.EntityAlreadyExistsException;
import com.itexcellence.core.exception.EntityNotFoundException;
import com.itexcellence.core.exception.InvalidInputException;
import com.itexcellence.core.exception.ResourceNotFoundException;
import com.itexcellence.core.model.ErrorMessage;
import com.itexcellence.core.model.Response;

import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;

@SuppressWarnings({ "rawtypes", "unchecked" })
@ControllerAdvice
public class ControllerExceptionHandler {

	@ExceptionHandler(ResourceNotFoundException.class)
	@ApiResponse(responseCode = "404", description = "Resource not found", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Response.class)))
	public ResponseEntity<Response> resourceNotFoundException(ResourceNotFoundException ex, WebRequest request) {
		Response response = new Response<>(MessageConstants.ERROR_MSG, LocalDateTime.now().toString(),
				MessageConstants.HTTP_CODE_404, ex.getMessage(), null, null);
		return new ResponseEntity(response, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(Exception.class)
	@ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Response.class)))
	public ResponseEntity<Response> globalExceptionHandler(Exception ex, WebRequest request) {
		Response response = new Response<>(MessageConstants.ERROR_MSG, LocalDateTime.now().toString(),
				HttpStatus.INTERNAL_SERVER_ERROR.value(), ex.getMessage(), null, null);
		return new ResponseEntity(response, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@ExceptionHandler(EntityNotFoundException.class)
	@ApiResponse(responseCode = "404", description = "Not Found", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Response.class)))
	public ResponseEntity<ErrorMessage> handleEntityNotFound(EntityNotFoundException ex, WebRequest request) {
		Response response = new Response<>(MessageConstants.ERROR_MSG, LocalDateTime.now().toString(),
				HttpStatus.NOT_FOUND.value(), ex.getMessage(), null, null);
		return new ResponseEntity(response, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(EntityAlreadyExistsException.class)
	@ApiResponse(responseCode = "409", description = "Conflict", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Response.class)))
	public ResponseEntity<Response> handleEntityAlreadyExists(EntityAlreadyExistsException ex, WebRequest request) {
		Response response = new Response<>(MessageConstants.ERROR_MSG, LocalDateTime.now().toString(),
				HttpStatus.CONFLICT.value(), ex.getMessage(), null, null);
		return new ResponseEntity(response, HttpStatus.CONFLICT);

	}

	@ExceptionHandler(InvalidInputException.class)
	@ApiResponse(responseCode = "400", description = "Bad Request", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Response.class)))
	public ResponseEntity<Response> handleInvalidInput(InvalidInputException ex, WebRequest request) {
		Response response = new Response<>(MessageConstants.ERROR_MSG, LocalDateTime.now().toString(),
				HttpStatus.BAD_REQUEST.value(), ex.getMessage(), null, null);
		return new ResponseEntity(response, HttpStatus.BAD_REQUEST);

	}

}