package com.itexcellence.core.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.itexcellence.core.entity.Employee;
import com.itexcellence.core.model.EmployeeVO;
import com.itexcellence.core.service.EmployeeService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/employees")
@Tag(name = "Employee Management", description = "APIs for managing employees")
public class EmployeeController {

	@Autowired
	private EmployeeService employeeService;

	@Operation(summary = "Add an employee to a department", description = "Add a new employee to a specific department")
	@PostMapping("/department/{departmentId}")
	public Employee addEmployeeToDepartment(@PathVariable Long departmentId, @RequestBody EmployeeVO employeeVO) {
		return employeeService.addEmployeeToDepartment(departmentId, employeeVO);
	}

	@Operation(summary = "Get all employees", description = "Retrieve a list of all employees")
	@GetMapping
	public List<EmployeeVO> getAllEmployees() {
		return employeeService.getAllEmployees();
	}

	@Operation(summary = "Get employees by department", description = "Retrieve employees in a specific department by department ID")
	@GetMapping("/department/{departmentId}")
	public List<EmployeeVO> getEmployeesByDepartment(@PathVariable Long departmentId) {
		return employeeService.getEmployeesByDepartmentId(departmentId);
	}

	@Operation(summary = "Delete an employee", description = "Delete an employee by their ID")
	@DeleteMapping("/{employeeId}")
	public void deleteEmployee(@PathVariable Long employeeId) {
		employeeService.deleteEmployee(employeeId);
	}
}