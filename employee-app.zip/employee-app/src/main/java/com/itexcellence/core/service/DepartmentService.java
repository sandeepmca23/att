package com.itexcellence.core.service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.itexcellence.core.constants.MessageConstants;
import com.itexcellence.core.entity.Department;
import com.itexcellence.core.exception.EntityAlreadyExistsException;
import com.itexcellence.core.exception.EntityNotFoundException;
import com.itexcellence.core.exception.ResourceNotFoundException;
import com.itexcellence.core.mapper.DepartmentMapper;
import com.itexcellence.core.model.DepartmentVO;
import com.itexcellence.core.model.DepartmentVO2;
import com.itexcellence.core.model.Pagination;
import com.itexcellence.core.model.Response;
import com.itexcellence.core.repository.DepartmentRepository;

@Service
@SuppressWarnings("rawtypes")
public class DepartmentService {
	@Autowired
	private DepartmentRepository departmentRepository;

	public Response createDepartment(DepartmentVO departmentVO) throws ResourceNotFoundException {
		Department department = DepartmentMapper.INSTANCE.toEntity(departmentVO);
		if (departmentRepository.existsById(departmentVO.getId())) {
			throw new EntityAlreadyExistsException(
					String.format(MessageConstants.DEPARTMENT_ALREADY_EXISTS, department.getId()));
		}
		Department savedDepartment = departmentRepository.save(department);
		return new Response<>(MessageConstants.SUCCESS_MSG, LocalDateTime.now().toString(),
				MessageConstants.HTTP_CODE_200, MessageConstants.DEPARTMENT_FETCHED_SUCCESS, savedDepartment, null);

	}

	public Response getDepartment(Long id) {
		Department department = departmentRepository.findById(id).orElseThrow(
				() -> new EntityNotFoundException(String.format(MessageConstants.DEPARTMENT_NOT_FOUND, id)));
		DepartmentVO departmentVO = DepartmentMapper.INSTANCE.toVO(department);
		return new Response<>(MessageConstants.SUCCESS_MSG, LocalDateTime.now().toString(),
				MessageConstants.HTTP_CODE_200, MessageConstants.DEPARTMENT_FETCHED_SUCCESS, departmentVO, null);
	}

	public Response getAllDepartmentsWithPagination(int page, int size) {
		Pageable pageable = PageRequest.of(page > 0 ? page : 0, size > 0 ? size : 10);
		Page<Department> departmentPage = departmentRepository.findAll(pageable);
		Pagination pagination = new Pagination(departmentPage.getNumber(), departmentPage.getSize(),
				departmentPage.getTotalElements(), departmentPage.getTotalPages());
		List<DepartmentVO> departmentVOs = departmentPage.getContent().stream().map(DepartmentMapper.INSTANCE::toVO)
				.collect(Collectors.toList());
		return new Response<>(MessageConstants.SUCCESS_MSG, LocalDateTime.now().toString(),
				MessageConstants.HTTP_CODE_200, MessageConstants.DEPARTMENTS_FETCHED_SUCCESS, departmentVOs,
				pagination);
	}

	public Response getDepartmentsWithEmployees(int page, int size) {
		Pageable pageable = PageRequest.of(page > 0 ? page : 0, size > 0 ? size : 10);
		Page<Department> departmentPage = departmentRepository.findAll(pageable);
		if (departmentPage.isEmpty()) {
			throw new EntityNotFoundException(MessageConstants.DEPARTMENTS_NOT_FOUND);
		}
		Pagination pagination = new Pagination(departmentPage.getNumber(), departmentPage.getSize(),
				departmentPage.getTotalElements(), departmentPage.getTotalPages());
		List<DepartmentVO> departmentVOs = departmentPage.getContent().stream().map(department -> {
			DepartmentVO2 departmentVO = DepartmentMapper.INSTANCE.toVO2(department);
			/*
			 * departmentVO.setEmployeeVOList(
			 * department.getEmployees().stream().map(EmployeeMapper.INSTANCE::toVO).collect
			 * (Collectors.toList()));
			 */
			return departmentVO;
		}).collect(Collectors.toList());
		return new Response<>(MessageConstants.SUCCESS_MSG, LocalDateTime.now().toString(),
				MessageConstants.HTTP_CODE_200, MessageConstants.DEPARTMENTS_FETCHED_SUCCESS, departmentVOs,
				pagination);
	}

	@Transactional
	public Department updateDepartment(Long id, DepartmentVO departmentVO) {
		Department existingDept = departmentRepository.findById(id).orElseThrow(
				() -> new EntityNotFoundException(String.format(MessageConstants.DEPARTMENT_NOT_FOUND, id)));
		existingDept.setName(departmentVO.getName());
		existingDept.setLocation(departmentVO.getLocation());
		return departmentRepository.save(existingDept);
	}
}