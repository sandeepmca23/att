package com.itexcellence.core.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.itexcellence.core.entity.Department;
import com.itexcellence.core.entity.Employee;
import com.itexcellence.core.mapper.EmployeeMapper;
import com.itexcellence.core.model.EmployeeVO;
import com.itexcellence.core.repository.DepartmentRepository;
import com.itexcellence.core.repository.EmployeeRepository;

@Service
@Transactional
public class EmployeeService {
	@Autowired
    private EmployeeRepository employeeRepository;

    @Autowired
    private DepartmentRepository departmentRepository;

   
    public Employee addEmployeeToDepartment(Long departmentId, EmployeeVO employeeVO) {
        Department department = departmentRepository.findById(departmentId).orElseThrow();
        Employee Employee = EmployeeMapper.INSTANCE.toEntity(employeeVO);
        Employee.setDepartment(department);  
        return employeeRepository.save(Employee);
    }

   
    public List<EmployeeVO> getAllEmployees() {
        List<Employee> employeeEntities = employeeRepository.findAll();
        return employeeEntities.stream()
                .map(EmployeeMapper.INSTANCE::toVO)
                .collect(Collectors.toList());
    }

   
    public List<EmployeeVO> getEmployeesByDepartmentId(Long departmentId) {
        List<Employee> employeeEntities = employeeRepository.findByDepartmentId(departmentId);
        return employeeEntities.stream()
                .map(EmployeeMapper.INSTANCE::toVO)
                .collect(Collectors.toList());
    }

   
    public void deleteEmployee(Long employeeId) {
        Employee Employee = employeeRepository.findById(employeeId).orElseThrow();
        employeeRepository.delete(Employee);
    }
}
