package com.itexcellence.core.config;

import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import io.swagger.v3.oas.models.servers.Server;

@Configuration
public class OpenAPIConfig {

	@Value("${demo.openapi.dev-url}")
	private String devUrl;

	@Value("${demo.openapi.prod-url}")
	private String prodUrl;

	@Bean
	public OpenAPI myOpenAPI() {
		Server devServer = new Server();
		devServer.setUrl(devUrl);
		devServer.setDescription("Server URL in Development environment");
		Server prodServer = new Server();
		prodServer.setUrl(prodUrl);
		prodServer.setDescription("Server URL in Production environment");
		Contact contact = new Contact();
		contact.setEmail("info@demo.com");
		contact.setName("proclivity");
		contact.setUrl("http://demo.com");
		License mitLicense = new License().name("demo License").url("https://demo.com");
		Info info = new Info().title("demo  Messaging APIs").version("1.0").contact(contact)
				.description("This documentation contains the description of all the financial messaging APIs")
				.termsOfService("https://demo.com/terms").license(mitLicense);
		return new OpenAPI().info(info).servers(List.of(devServer, prodServer));
	}
}
