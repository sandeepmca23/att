package com.itexcellence.core.constants;

public class MessageConstants {
	public static final String DEPARTMENT_NOT_FOUND = "Department with id %d not found";
    public static final String DEPARTMENT_ALREADY_EXISTS = "Department with id %d already exists";
    public static final String EMPLOYEE_NOT_FOUND = "Employee with id %d not found";
    public static final String EMPLOYEE_ALREADY_EXISTS = "Employee with id %d already exists";
    public static final String INTERNAL_SERVER_ERROR = "An unexpected error occurred. Please try again later.";
    public static final String DEPARTMENTS_NOT_FOUND = "No departments found";
    public static final String DEPARTMENT_CREATED_SUCCESS = "Department created successfully";
    public static final String EMPLOYEE_CREATED_SUCCESS = "Employee created successfully";
    public static final String DEPARTMENT_FETCHED_SUCCESS = "Department fetched successfully";
    public static final String GENERIC_ERROR = "An error occurred while processing the request";
    public static final String DEPARTMENTS_FETCHED_SUCCESS="";
    public static final String SUCCESS_MSG= "success";
    public static final String ERROR_MSG= "error";
    public static final Integer HTTP_CODE_200= 200;
    public static final Integer HTTP_CODE_404=404;
   
    
    
    
    
}
