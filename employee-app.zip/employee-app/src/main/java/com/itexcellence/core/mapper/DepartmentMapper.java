package com.itexcellence.core.mapper;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.itexcellence.core.entity.Department;
import com.itexcellence.core.model.DepartmentVO;
import com.itexcellence.core.model.DepartmentVO2;

@Mapper
public interface DepartmentMapper {

    DepartmentMapper INSTANCE = Mappers.getMapper(DepartmentMapper.class);

    Department toEntity(DepartmentVO vo);

    DepartmentVO toVO(Department entity);
    
    DepartmentVO2 toVO2(Department entity);
}
