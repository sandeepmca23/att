package com.itexcellence.core.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.itexcellence.core.entity.Department;
import com.itexcellence.core.model.DepartmentVO;
import com.itexcellence.core.model.Response;
import com.itexcellence.core.service.DepartmentService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping("/api/departments")
@Tag(name = "Department Management", description = "APIs for managing departments")
@SuppressWarnings("rawtypes")
public class DepartmentController {

	@Autowired
	private DepartmentService departmentService;

	@Operation(summary = "Create a new Department", description = "Add a new department to the system")
	@ApiResponses({
			@ApiResponse(responseCode = "201", description = "Department created successfully", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Response.class))),
			@ApiResponse(responseCode = "400", description = "Validation error or invalid input", content = @Content(mediaType = "application/json")),
			@ApiResponse(responseCode = "409", description = "Department already exists", content = @Content(mediaType = "application/json")) })
	@PostMapping
	public ResponseEntity<Response> createDepartment(@RequestBody DepartmentVO departmentVO) {
		Response response = departmentService.createDepartment(departmentVO);
		return new ResponseEntity<>(response, HttpStatus.CREATED);
	}

	@Operation(summary = "Fetch Department Details", description = "Retrieve details of a department by its ID.")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "Department fetched successfully", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Response.class))),
			@ApiResponse(responseCode = "404", description = "Department not found", content = @Content(mediaType = "application/json")) })
	@GetMapping("/{id}")
	public ResponseEntity<Response> getDepartment(@PathVariable Long id) {
		Response response = departmentService.getDepartment(id);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@SuppressWarnings("unchecked")
	@Operation(summary = "Fetch Departments with Employees", description = "Retrieve a paginated list of departments along with their employees.")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "Departments fetched successfully", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Response.class))),
			@ApiResponse(responseCode = "404", description = "No departments found", content = @Content(mediaType = "application/json")) })
	@GetMapping
	public ResponseEntity<Response<List<DepartmentVO>>> getDepartmentsWithEmployees(
			@RequestParam(defaultValue = "0") int page, @RequestParam(defaultValue = "10") int size) {
		Response<List<DepartmentVO>> response = departmentService.getDepartmentsWithEmployees(page, size);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@Operation(summary = "Update Department", description = "Update the details of an existing department by its ID.")
	@ApiResponses({
			@ApiResponse(responseCode = "200", description = "Department updated successfully", content = @Content(mediaType = "application/json", schema = @Schema(implementation = Department.class))),
			@ApiResponse(responseCode = "404", description = "Department not found", content = @Content(mediaType = "application/json")),
			@ApiResponse(responseCode = "400", description = "Invalid input", content = @Content(mediaType = "application/json")) })
	@PutMapping("/{id}")
	public ResponseEntity<Department> updateDepartment(@PathVariable Long id, @RequestBody DepartmentVO departmentVO) {
		Department updatedDepartment = departmentService.updateDepartment(id, departmentVO);
		return new ResponseEntity<>(updatedDepartment, HttpStatus.OK);
	}

}
