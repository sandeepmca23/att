import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VarificationUserComponent } from './varification-user.component';

describe('VarificationUserComponent', () => {
  let component: VarificationUserComponent;
  let fixture: ComponentFixture<VarificationUserComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ VarificationUserComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(VarificationUserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
