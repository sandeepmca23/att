package com.att.ads.service;

import java.util.List;
import java.util.Map;

public interface CreateticketService {

	void getCreateticketDropdownList( Map<String, List<String>> dropdownMap);

}
