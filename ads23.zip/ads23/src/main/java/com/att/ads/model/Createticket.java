package com.att.ads.model;

public class Createticket {
	
	private String createAction;
	private String templateAction;
	private String newTicketAction;
	private String importDataAction;
	private String ticketSelectOption;
	private String numberOfTickets;
	private String bulkTicketId;
	private String bulkTemplateName;
	public String getCreateAction() {
		return createAction;
	}
	public void setCreateAction(String createAction) {
		this.createAction = createAction;
	}
	public String getTemplateAction() {
		return templateAction;
	}
	public void setTemplateAction(String templateAction) {
		this.templateAction = templateAction;
	}
	public String getNewTicketAction() {
		return newTicketAction;
	}
	public void setNewTicketAction(String newTicketAction) {
		this.newTicketAction = newTicketAction;
	}
	public String getImportDataAction() {
		return importDataAction;
	}
	public void setImportDataAction(String importDataAction) {
		this.importDataAction = importDataAction;
	}
	public String getTicketSelectOption() {
		return ticketSelectOption;
	}
	public void setTicketSelectOption(String ticketSelectOption) {
		this.ticketSelectOption = ticketSelectOption;
	}
	public String getNumberOfTickets() {
		return numberOfTickets;
	}
	public void setNumberOfTickets(String numberOfTickets) {
		this.numberOfTickets = numberOfTickets;
	}
	public String getBulkTicketId() {
		return bulkTicketId;
	}
	public void setBulkTicketId(String bulkTicketId) {
		this.bulkTicketId = bulkTicketId;
	}
	public String getBulkTemplateName() {
		return bulkTemplateName;
	}
	public void setBulkTemplateName(String bulkTemplateName) {
		this.bulkTemplateName = bulkTemplateName;
	}


}
