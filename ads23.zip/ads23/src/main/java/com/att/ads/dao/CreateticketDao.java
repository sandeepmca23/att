package com.att.ads.dao;

import java.util.List;
import java.util.Map;

public interface CreateticketDao {
	void getCreateticketDropdownList(Map<String, List<String>> dropdownMap);
}
